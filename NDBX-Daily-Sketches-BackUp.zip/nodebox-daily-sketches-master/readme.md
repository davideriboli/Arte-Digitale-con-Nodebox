### daily nodebox sketches

area for me to store/share sketches using [nodebox 3](https://www.nodebox.net/node/)

------------------

view via gitHub pages: [sketches index](https://eesur.github.io/nodebox-daily-sketches/)

------------------

**code** is a folder containing nodebox source files
**img-refs** is a folder of corresponding images for each sketch

note: both labelled `year-month-date`


------------------


![2017-may-14](https://cloud.githubusercontent.com/assets/1597761/26145923/43c17f4e-3ae6-11e7-816f-55be81dba22f.gif)