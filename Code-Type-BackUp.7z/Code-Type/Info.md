**Info**<br />I found this stuff at URL http://code-type.com/; it's a series of files with generative typographic variations. The site does not report author or license.

By running a whois query the only information you get is that it is hosted by GoDaddy. Contacting the author or an admin seems impossible. Since I really liked the code, I thought it was a good idea to keep a copy of it here, available to anyone interested. 

Of course, if the author disagrees can contact me to request removal.

![Previews](screenshot-code-type.com-2020.06.28-18_35_51.png)