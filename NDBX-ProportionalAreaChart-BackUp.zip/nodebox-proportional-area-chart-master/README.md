This repo is for sketches mentioned in [this article written on medium](https://medium.com/@eesur/proportional-area-chart-nodebox-3-86bc4bb03d2f) to make a Proportional Area Chart using the awesome [NodeBox 3](https://www.nodebox.net/node/)

---

