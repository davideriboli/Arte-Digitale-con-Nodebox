package nodebox.client;


public interface Selectable {
    public void setSelected(boolean s);

    public boolean isSelected();
}

