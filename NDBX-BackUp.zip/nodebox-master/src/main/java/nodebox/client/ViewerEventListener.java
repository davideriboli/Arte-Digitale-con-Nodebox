package nodebox.client;

/**
 * The listener that receives events whenever items in the viewer change.
 */
public interface ViewerEventListener {
}
