package nodebox.ui;

/**
 * Marking interface for views that can live inside of a Pane.
 *
 * @see Pane
 */
public interface PaneView {
}
