def concat(s1, s2):
    return "%s%s" % (s1, s2)