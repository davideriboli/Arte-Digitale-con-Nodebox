def add(*args):
    return sum(args)

def multiply(v1, v2):
    return v1 * v2