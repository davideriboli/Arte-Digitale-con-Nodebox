; Clojure math library for testing.
(ns clojure-math)

(def add +)
