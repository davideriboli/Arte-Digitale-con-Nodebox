; This example does not end with a var definition at the end.
(ns no-var-at-end)

[{:name "add" :fn +}]

